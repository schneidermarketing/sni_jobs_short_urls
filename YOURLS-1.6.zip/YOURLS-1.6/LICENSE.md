        __     ______  _    _ _____  _       _____ 
        \ \   / / __ \| |  | |  __ \| |     / ____|
         \ \_/ / |  | | |  | | |__) | |    | (___  
          \   /| |  | | |  | |  _  /| |     \___ \ 
           | | | |__| | |__| | | \ \| |____ ____) |
           |_|  \____/ \____/|_|  \_\______|_____/ 

YOURLS - Your Own URL Shortener - A URL shortening script

---------------------------------------------------------------

This program is free software. Do whatever the hell you want with it.

This program is distributed in the hope that it will be useful and/or
fun to use. There is absolutely no guarantee of any kind about anything.

For more text, have a look at http://www.gnu.org/licenses/gpl.txt

---------------------------------------------------------------

This software incorporates code stolen from WordPress, as shown by
comments in source where applicable.

---------------------------------------------------------------

By Lester CHAN (initial idea), Ozh RICHARD (development) and contributors.
